 <div align="center"> 
  <img  src="t.png" height="100px" width="150px"> </img>
  <p> <h2 align="center" style="color: Black">  Tinker  <sub style="color:black">e-commerce </sub></h2> </p>
     <table style="width:100%; border:1px solid  #b3b3b3">
        <tr  style="background-color:#FFE4B5;">
        <th style="border: 5px solid #FFE4B5;"><a style="text-decoration:none; color:#000000;" href="adlogin.php">Admin</a></th>
        <th style="border: 5px solid #FFE4B5;"><a style="text-decoration:none; color:#000000;" href=" ">Store Owner</a></th>
        <th style="border: 5px solid #FFE4B5;"><a style="text-decoration:none; color:#000000;" href=" ">Customer</a></th>
        <th style="border: 5px solid #FFE4B5;"><a style="text-decoration:none; color:#000000;" href=" ">Employee</a></th>

        
    </tr>
    </table>
 </div>

