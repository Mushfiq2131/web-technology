 <div align="center"> 
  <img  src="t.png" height="100px" width="150px"> </img>
  <p> <h1 align="" style="color: green">  Tinker  <sub style="color:black">e-commerce </sub></h1> </p>
  <h3 align= "right">  
        Logged in as <?php echo $_SESSION['username']; ?>|<a href="../controller/logoutcontroller.php">Logout</a>           
      </h3>
    <table style="width:100%; border:1px solid  #b3b3b3">
    <tr  style="background-color:#04AA6D;">
        <th style="border: 5px solid #04AA6D;"><a style="text-decoration:none; color:#fff;" href="dashboard.php">Dashboard</a></th>
        <th style="border: 5px solid #04AA6D;"><a style="text-decoration:none; color:#fff;" href="viewprofile.php">View Profile</a></th>
        <th style="border: 5px solid #04AA6D;"><a style="text-decoration:none; color:#fff;" href="editprofile.php">Edit Profile</a></th>
        <th style="border: 5px solid #04AA6D;"><a style="text-decoration:none; color:#fff;" href="changepass.php">Change Password</a></th>   
        <th style="border: 5px solid #04AA6D;"><a style="text-decoration:none; color:#fff;" href="propic.php">Change Profile Picture</a></th>
    </tr>
    </table>
