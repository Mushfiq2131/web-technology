<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
    .footer {
        position: fixed;
        left: 0;
        bottom: 0;
        width: 100%;
        background-color: cyan;
        color: black;
        text-align: center;
    }
    </style>
</head>
<body>
    <div class="footer">
        <p>Copyright @2021</p>
    </div>
</body>
</html>