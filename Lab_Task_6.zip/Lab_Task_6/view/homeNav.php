 <div align="center"> 
  <img  src="t.png" height="200px" width="250px"> </img> <br>
  <p> <h1 align="center" style="color: green">  Tinker  <sub style="color:black">e-commerce </sub></h1> </p>
     <table style="width:100%; border:1px solid  #b3b3b3">
        <tr  style="background-color:#04AA6D;">
        <th style="border: 5px solid #04AA6D;"><a style="text-decoration:none; color:#fff;" href="adlogin.php">Admin</a></th>
        <th style="border: 5px solid #04AA6D;"><a style="text-decoration:none; color:#fff;" href=" ">Store Owner</a></th>
        <th style="border: 5px solid #04AA6D;"><a style="text-decoration:none; color:#fff;" href=" ">Customer</a></th>
        <th style="border: 5px solid #04AA6D;"><a style="text-decoration:none; color:#fff;" href=" ">Employee</a></th>
        
    </tr>
    </table>
