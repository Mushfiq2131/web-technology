<?php

header("location: view/home.php");
include ("../model/connection.php");
?>
