<!DOCTYPE html>

<html>
     
	 <head>
	     <title> PUBLIC HOME </title>
	 
	 </head>
	     
	 <body>
	 
	    <br>
	    <fieldset>
		   <div> 
		   
		      <p ><h1 style="color: green">  X  <sub style="color:black">Company </sub> <h1> </p> 
		 
		 
		   
		       <h3 align= "right">
		 
		 
			   <a style="color:SlateBlu;" href="http://localhost/PHP/Lab_Task_4/Public%20Home/PublicHome.php">  Home |  </a> 
		       <a style="color:SlateBlu;" href="http://localhost/PHP/Lab_Task_4/Login/Login.php">  Login |  </a>  
		       <a style="color:SlateBlu;" href="http://localhost/PHP/Lab_Task_4/Store%20Data/StoreData.php">  Registration </a> 
		 
		  
		   </h3>
		   
		  <hr>
		  
		</div> 

	    <div>
	    	<legend>

		   <p> <h1 align="left" > Welcome to <sub style="color:green" > X <sup style="color:black">Company </sub> </p> <br> <br>
		   
		     <hr>
	      </div>
		   
		   <div align="center">
		   
		   <h4 > <span style="color: rgb(140, 140, 140);"> Copyright ©  <?php echo date(2017);?> </span> </h4>
		   </legend>
		   </div>
		   </fieldset>
	 </body>
	 
</html>