<!DOCTYPE html>

<html>
     <fieldset>
	 <head>
	     <title> Profile </title>
	 
	 </head>
	     
	 <body>
	 
	    <br> 
		
		   <div> 
		   
		     <p> <h1 style="color: green">  X  <sub style="color:black"> Company </sub> <h1> </p>
		 
		   
		       <h2 align= "right">
		 
		 
		        Logged in as<a style ="color:SlateBlu;"  href= "http://localhost/PHP/Lab_Task_4/Profile/Profile.php"> Bob | </a>
		       <a style="color:SlateBlu;" href="http://localhost/PHP/Lab_Task_4/Login/Login.php">  Logout </a>  
		       
		 
		  
		   </h2>
		   
		  <hr>
		  
		</div> 
			<fieldset><fieldset>
			
	      <legend><h2> <u> Account </u> </h2> <style="color: rgb(255, 255, 255);"> </legend> 
		   
		    
		   
            <h2>
			<ul>
                <li> <a style="color:SlateBlu;" href="http://localhost/PHP/Lab_Task_4/Dash%20Board/DashBoard.php">  Dashboard   </a></li> 
                <li> <a style ="color:SlateBlu;"  href= "http://localhost/PHP/Lab_Task_4/Profile/Profile.php"> View Profile </a> </li>
                <li> <a style ="color:SlateBlu;" href="http://localhost/PHP/Lab_Task_4/Edit%20profile/Editprofile.php"> Edit Profile <a> </li>
				<li> <a style ="color:SlateBlu;" href="http://localhost/PHP/Lab_Task_4/Change%20Profile/ChangeProfilePicture.php">Change Profile Picture</a> </li>
                <li> <a style ="color:SlateBlu;" href="http://localhost/PHP/Lab_Task_4/Change%20Password/ChangePassword.php">Change Password</a> </li>
                <li> <a style ="color:SlateBlu;" href="http://localhost/PHP/Lab_Task_4/Login/Login.php">Logout</a> </li>
                 
		     </ul> 
		     </h2></fieldset>
		 </fieldset><br>
			 
		   <div>
		   
		   
			<fieldset><fieldset>
		    <legend align="center"><h1> PROFILE </h1></legend>
			
			<h3 align="center">
		    
			<img  src="c.png" height="200px" width="250px"  > </img> <br>
			<a align="right" href="http://localhost/PHP/Lab_Task_4/Change%20Profile/ChangeProfilePicture.php"> Change </a> <br><br>
			
			
			
		      Name <span style="color: rgb(255, 255, 255);"> </span>: Bob <hr>
	          Email <span style="color: rgb(255, 255, 255);"> </span> : bob@aiub.edu <hr>
		      Gender<span style="color: rgb(255, 255, 255);"> </span>: Male <hr>
		      Date of Birth <span style="color: rgb(255, 255, 255);"> </span>: 19.09.1998 <hr>

		   
		    <a tyle ="color:SlateBlu;"  href="http://localhost/PHP/Lab_Task_4/Edit%20profile/Editprofile.php"> Edit Profile </a>
			
			</h3>
			</fieldset>
		    </fieldset>
			
		</div>
		
		   <div align="center">
		   
		    <hr>
		   
		   <h4> <span style="color: rgb(140, 140, 140);"> Copyright Š  <?php echo date(2017);?> </span> </h4>
		   
		   </div>
		   
	 </body>
	 </fieldset>
</html>