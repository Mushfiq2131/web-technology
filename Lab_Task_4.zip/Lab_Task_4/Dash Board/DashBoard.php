<!DOCTYPE html>

<html>
<fieldset>
     
	 <head>
	     <title> DASHBOARD </title>
	   
	 </head>
	     
	 <body>
	 
	    <br>
		   <div> 
		   
		      <p> <h1 style="color: green"> X  <sub style="color:black">Company</sub> </h1> </p>
		 
		   
		       <h3 align= "right">
		 
		 
		        
		       <a style="color:SlateBlu;" href="http://localhost/PHP/Lab_Task_4/Login/Login.php">  Login |  </a>  
		       <a style="color:SlateBlu;" href="http://localhost/PHP/Lab_Task_4/Store%20Data/StoreData.php">  Registration </a> 
		 
		  
		   </h3>
		   
		  <hr>
		  
		</div> 
		
		<div>
			<fieldset>
		
		  <legend> <h2> <u> Account </u> </h2></legend> <style="color: rgb(255, 255, 255);"> <h1 align="center" ><h1/>
		   
		    
		   
            <h2>
            <ul>
                <li> <a style="color:SlateBlu;" href="http://localhost/PHP/Lab_Task_4/Dash%20Board/DashBoard.php">  Dashboard   </a></li> 
                <li> <a style ="color:SlateBlu;"  href= "http://localhost/PHP/Lab_Task_4/Profile/Profile.php"> View Profile </a> </li>
                <li> <a style ="color:SlateBlu;" href="http://localhost/PHP/Lab_Task_4/Edit%20profile/Editprofile.php"> Edit Profile <a> </li>
				<li> <a style ="color:SlateBlu;" href="http://localhost/PHP/Lab_Task_4/Change%20Profile/ChangeProfilePicture.php">Change Profile Picture</a> </li>
                <li> <a style ="color:SlateBlu;" href="http://localhost/PHP/Lab_Task_4/Change%20Password/ChangePassword.php">Change Password</a> </li>
                <li> <a style ="color:SlateBlu;" href="http://localhost/PHP/Lab_Task_4/Login/Login.php">Logout</a> </li>
                 
		     </ul> 
		     </h2>
		   
		  
		   
		     <hr>
	     
		  
		</fieldset>

		<fieldset>

		<legend align="center"><h1  > Welcome Bob  <h1/></legend>
			<span> <p> </p> </span>
		</fieldset>
		
		<div/>
		
	    <div align="center">
		
		    <h5> <span style="color: rgb(140, 140, 140);"> Copyright ©  <?php echo date(2017);?> <span/> <h5/>
		   
		 </div>
		   
	 </body>
	 </fieldset>
</html>	 