<?php

require_once ('../model/model.php');

function fetchAllAd(){
	return showAllAd();

}

function fetchImage($name)
{
  return showImage($name);
}

?>