 <div align="center"> 
  <img  src="t.png" height="200px" width="250px"> </img> <br>
  <p> <h1 align="center" style="color: green">  Tinker  <sub style="color:black">e-commerce </sub></h1> </p>
     <table style="width:100%; border:1px solid  #b3b3b3">
    <tr  style="background-color:#04AA6D;">
        
      
        <th style="border: 5px ;width: 500px;"><a style="text-decoration:none;" href=""></a></th>
       
        <th style="border: 5px solid #04AA6D; width: 10px;"><a style="text-decoration:none; color:#fff;" href="../view/dashboard.php">Go to Dashboard</a></th>
      
    </tr>
    </table>
